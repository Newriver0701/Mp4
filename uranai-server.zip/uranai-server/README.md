# 占いリール 動画エクスポーター

## Railwayへのデプロイ手順

1. このフォルダをGitHubにアップロード
2. https://railway.app にアクセス → GitHubでログイン
3. 「New Project → Deploy from GitHub repo」
4. リポジトリを選ぶ → 自動デプロイ開始
5. 発行されたURLにアクセス

## ファイル構成
- `server.js` — Node.jsサーバー（FFmpegで動画生成）
- `public/index.html` — フロントエンド
- `nixpacks.toml` — FFmpegのインストール設定
- `package.json` — 依存関係
